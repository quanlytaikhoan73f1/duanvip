"use client";

import { useState } from "react";
import { CalendarRange, CheckCircle2, Clock4, Users } from "lucide-react";
import AttendanceEntryEditor from "@/components/personal/AttendanceEntryEditor";
import MonthAttendanceTable from "@/components/personal/MonthAttendanceTable";
import StatCard from "@/components/ui/StatCard";
import { useWorkbookData } from "@/components/providers/WorkbookDataProvider";
import { formatCurrency } from "@/lib/utils";
import type { MonthData } from "@/lib/types";

function getDefaultSelectedDay(month: MonthData) {
  return month.entries.find((entry) => entry.hasActivity)?.day || 1;
}

export default function AttendancePage() {
  const { data, latestMonth, getMonthOwnerSummary, saveEntry, clearEntry } = useWorkbookData();
  const [selectedMonthId, setSelectedMonthId] = useState(latestMonth.id);
  const [showEmptyDays, setShowEmptyDays] = useState(true);

  const selectedMonth =
    data.months.find((month) => month.id === selectedMonthId) || latestMonth;
  const [selectedDay, setSelectedDay] = useState(() => getDefaultSelectedDay(selectedMonth));
  const ownerRows = getMonthOwnerSummary(selectedMonth.id);
  const activeEntries = selectedMonth.entries.filter((entry) => entry.hasActivity);
  const selectedEntry =
    selectedMonth.entries.find((entry) => entry.day === selectedDay) || selectedMonth.entries[0];

  const workingDays = activeEntries.filter(
    (entry) => entry.mark === "O" || entry.mark === "N"
  ).length;

  return (
    <div className="space-y-8">
      <section className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="section-title">Attendance ledger</p>
          <h1 className="mt-3 text-3xl font-black uppercase tracking-tight text-slate-100">
            Chi tiet cham cong tung thang
          </h1>
          <p className="mt-3 max-w-2xl text-slate-400">
            Chon ngay trong bang de nhap moi hoac chinh sua. Sau khi luu, dashboard va cac bao
            cao se tinh lai ngay theo du lieu moi.
          </p>
        </div>

        <div className="glass-card flex flex-wrap gap-2 rounded-3xl p-2">
          {data.months.map((month) => (
            <button
              key={month.id}
              onClick={() => {
                setSelectedMonthId(month.id);
                setSelectedDay(getDefaultSelectedDay(month));
              }}
              className={`rounded-2xl px-4 py-2 text-xs font-black uppercase transition-all ${
                selectedMonth.id === month.id
                  ? "bg-emerald-500 text-slate-950"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-100"
              }`}
            >
              {month.label}
            </button>
          ))}
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard
          title="Ngay co du lieu"
          value={workingDays}
          description={`Thang ${selectedMonth.monthNumber}`}
          icon={CalendarRange}
          color="emerald"
        />
        <StatCard
          title="Cong quy doi"
          value={selectedMonth.summary.workUnits}
          description={`${selectedMonth.summary.countO} O / ${selectedMonth.summary.countN} N`}
          icon={CheckCircle2}
          color="sky"
        />
        <StatCard
          title="Owner active"
          value={ownerRows.length}
          description="So chu cong tac trong thang"
          icon={Users}
          color="amber"
        />
        <StatCard
          title="Gross thang"
          value={formatCurrency(selectedMonth.summary.gross)}
          description={`Net ${formatCurrency(selectedMonth.summary.net)}`}
          icon={Clock4}
          color="rose"
        />
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.2fr,0.8fr]">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="section-title">Timesheet</p>
              <h2 className="mt-1 text-xl font-black text-slate-100">
                Bang chi tiet {selectedMonth.label}
              </h2>
            </div>
            <label className="flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-300">
              <input
                type="checkbox"
                checked={showEmptyDays}
                onChange={(event) => setShowEmptyDays(event.target.checked)}
              />
              Hien ca ngay trong
            </label>
          </div>
          <MonthAttendanceTable
            entries={selectedMonth.entries}
            showEmptyDays={showEmptyDays}
            selectedEntryId={selectedEntry.id}
            onSelectEntry={(entry) => setSelectedDay(entry.day)}
          />
        </div>

        <div className="space-y-6">
          <AttendanceEntryEditor
            key={selectedEntry.id}
            entry={selectedEntry}
            monthLabel={selectedMonth.label}
            onSave={(values) => saveEntry(selectedMonth.id, selectedEntry.day, values)}
            onClear={() => clearEntry(selectedMonth.id, selectedEntry.day)}
          />

          <div className="glass-card rounded-3xl p-6">
            <p className="section-title">Owner breakdown</p>
            <h2 className="mt-2 text-xl font-black text-slate-100">Hieu suat theo chu</h2>
            <div className="mt-5 space-y-3">
              {ownerRows.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-white/10 bg-white/5 p-4 text-sm text-slate-400">
                  Thang nay chua co owner nao duoc ghi trong workbook.
                </div>
              ) : (
                ownerRows.map((owner) => (
                  <div key={owner.owner} className="rounded-2xl border border-white/8 bg-white/5 p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="font-black uppercase text-slate-100">{owner.owner}</div>
                        <div className="mt-1 text-xs text-slate-500">
                          {owner.daysWorked} ngay co mat 繚 {owner.workUnits} cong quy doi
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-black text-emerald-300">
                          {formatCurrency(owner.net)}
                        </div>
                        <div className="mt-1 text-xs text-slate-500">
                          Gross {formatCurrency(owner.gross)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
