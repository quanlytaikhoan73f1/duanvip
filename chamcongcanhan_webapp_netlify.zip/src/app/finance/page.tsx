"use client";

import dynamic from "next/dynamic";
import { useMemo, useState } from "react";
import { Coins, HandCoins, ReceiptText, Wallet } from "lucide-react";
import StatCard from "@/components/ui/StatCard";
import { useWorkbookData } from "@/components/providers/WorkbookDataProvider";
import { formatCurrency } from "@/lib/utils";

const MonthlyIncomeChart = dynamic(() => import("@/components/charts/MonthlyIncomeChart"), {
  ssr: false,
});

export default function FinancePage() {
  const { data, latestMonth, getMonthOwnerSummary } = useWorkbookData();
  const [selectedMonthId, setSelectedMonthId] = useState(latestMonth.id);

  const selectedMonth =
    data.months.find((month) => month.id === selectedMonthId) || latestMonth;
  const ownerRows = getMonthOwnerSummary(selectedMonth.id);

  const monthlyTrend = useMemo(
    () =>
      data.months.map((month) => ({
        label: `T${String(month.monthNumber).padStart(2, "0")}`,
        gross: month.summary.gross,
        net: month.summary.net,
        advance: month.summary.advance,
      })),
    [data.months]
  );

  const activeRows = selectedMonth.entries.filter((entry) => entry.hasActivity);
  const averageRate =
    selectedMonth.summary.workUnits > 0
      ? selectedMonth.summary.gross / selectedMonth.summary.workUnits
      : 0;

  return (
    <div className="space-y-8">
      <section className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="section-title">Cash flow</p>
          <h1 className="mt-3 text-3xl font-black uppercase tracking-tight text-slate-100">
            Dong tien va thuc lanh
          </h1>
          <p className="mt-3 max-w-2xl text-slate-400">
            Theo doi gross, advance, net theo thang va theo tung owner. Muc tieu la nhin nhanh
            duoc thang nao tao doanh thu, owner nao dong gop lon, va muc tien cong binh quan.
          </p>
        </div>

        <div className="glass-card flex flex-wrap gap-2 rounded-3xl p-2">
          {data.months.map((month) => (
            <button
              key={month.id}
              onClick={() => setSelectedMonthId(month.id)}
              className={`rounded-2xl px-4 py-2 text-xs font-black uppercase transition-all ${
                selectedMonth.id === month.id
                  ? "bg-sky-500 text-slate-950"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-100"
              }`}
            >
              {month.label}
            </button>
          ))}
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard
          title="Gross"
          value={formatCurrency(selectedMonth.summary.gross)}
          description={selectedMonth.label}
          icon={Wallet}
          color="emerald"
        />
        <StatCard
          title="Advance"
          value={formatCurrency(selectedMonth.summary.advance)}
          description="Tong da ung trong thang"
          icon={HandCoins}
          color="amber"
        />
        <StatCard
          title="Net"
          value={formatCurrency(selectedMonth.summary.net)}
          description="Tien con lai thuc nhan"
          icon={Coins}
          color="sky"
        />
        <StatCard
          title="Rate binh quan"
          value={formatCurrency(averageRate)}
          description="Gross / cong quy doi"
          icon={ReceiptText}
          color="rose"
        />
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.3fr,0.7fr]">
        <div className="glass-card rounded-3xl p-6">
          <p className="section-title">Trend</p>
          <h2 className="mt-2 text-xl font-black text-slate-100">Dong tien theo thang</h2>
          <MonthlyIncomeChart data={monthlyTrend} />
        </div>

        <div className="glass-card rounded-3xl p-6">
          <p className="section-title">Selected month</p>
          <h2 className="mt-2 text-xl font-black text-slate-100">Thong so {selectedMonth.label}</h2>
          <div className="mt-5 space-y-3">
            <div className="rounded-2xl bg-white/5 p-4">
              <div className="text-xs uppercase text-slate-500">Ngay co du lieu</div>
              <div className="mt-2 text-2xl font-black text-slate-100">{activeRows.length}</div>
            </div>
            <div className="rounded-2xl bg-white/5 p-4">
              <div className="text-xs uppercase text-slate-500">Owner active</div>
              <div className="mt-2 text-2xl font-black text-slate-100">{ownerRows.length}</div>
            </div>
            <div className="rounded-2xl bg-white/5 p-4">
              <div className="text-xs uppercase text-slate-500">O / N / X</div>
              <div className="mt-2 text-lg font-black text-slate-100">
                {selectedMonth.summary.countO} / {selectedMonth.summary.countN} / {selectedMonth.summary.countX}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="glass-card overflow-hidden rounded-3xl">
        <div className="border-b border-white/10 px-6 py-5">
          <p className="section-title">Owner payout</p>
          <h2 className="mt-2 text-xl font-black text-slate-100">Bang owner va tien nhan</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-white/5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">
              <tr>
                <th className="px-6 py-4">Owner</th>
                <th className="px-6 py-4 text-right">Cong quy doi</th>
                <th className="px-6 py-4 text-right">Gross</th>
                <th className="px-6 py-4 text-right">Advance</th>
                <th className="px-6 py-4 text-right">Net</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {ownerRows.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-slate-500">
                    Chua co owner nao trong thang nay.
                  </td>
                </tr>
              ) : (
                ownerRows.map((owner) => (
                  <tr key={owner.owner} className="hover:bg-white/5">
                    <td className="px-6 py-4 font-black text-slate-100">{owner.owner}</td>
                    <td className="px-6 py-4 text-right text-slate-300">{owner.workUnits}</td>
                    <td className="px-6 py-4 text-right text-slate-100">{formatCurrency(owner.gross)}</td>
                    <td className="px-6 py-4 text-right text-amber-300">{formatCurrency(owner.advance)}</td>
                    <td className="px-6 py-4 text-right font-black text-emerald-300">{formatCurrency(owner.net)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
