import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import AppShell from "@/components/layout/AppShell";
import { WorkbookDataProvider } from "@/components/providers/WorkbookDataProvider";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Cham cong ca nhan | Cuong",
  description: "Web app tong hop cham cong, dong tien, va dashboard tu workbook Excel ca nhan.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        <WorkbookDataProvider>
          <AppShell>{children}</AppShell>
        </WorkbookDataProvider>
      </body>
    </html>
  );
}
