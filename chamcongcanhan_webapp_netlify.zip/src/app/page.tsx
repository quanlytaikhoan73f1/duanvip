"use client";

import dynamic from "next/dynamic";
import { useMemo } from "react";
import {
  CalendarClock,
  Landmark,
  Sparkles,
  Target,
  TrendingUp,
} from "lucide-react";
import StatCard from "@/components/ui/StatCard";
import { useWorkbookData } from "@/components/providers/WorkbookDataProvider";
import { formatCompactCurrency, formatCurrency } from "@/lib/utils";

const MonthlyIncomeChart = dynamic(() => import("@/components/charts/MonthlyIncomeChart"), {
  ssr: false,
});
const OwnerNetChart = dynamic(() => import("@/components/charts/OwnerNetChart"), {
  ssr: false,
});
const AttendanceMixChart = dynamic(() => import("@/components/charts/AttendanceMixChart"), {
  ssr: false,
});

export default function DashboardPage() {
  const { data, latestMonth } = useWorkbookData();

  const monthlyTrend = useMemo(
    () =>
      data.months.map((month) => ({
        label: `T${String(month.monthNumber).padStart(2, "0")}`,
        gross: month.summary.gross,
        net: month.summary.net,
        advance: month.summary.advance,
      })),
    [data.months]
  );

  const ownerTrend = useMemo(
    () =>
      data.owners.slice(0, 6).map((owner) => ({
        owner: owner.owner,
        net: owner.net,
        gross: owner.gross,
      })),
    [data.owners]
  );

  const attendanceMix = useMemo(
    () => [
      { label: "Ca ngay", value: data.totals.countO },
      { label: "Nua ngay", value: data.totals.countN },
      { label: "Nghi", value: data.totals.countX },
    ],
    [data.totals]
  );

  const latestEntries = useMemo(
    () =>
      data.months
        .flatMap((month) => month.entries)
        .filter((entry) => entry.hasActivity)
        .sort((left, right) => right.date.localeCompare(left.date))
        .slice(0, 6),
    [data.months]
  );

  const bestOwner = data.owners[0];

  return (
    <div className="space-y-8">
      <section className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-3xl">
          <p className="section-title">Executive dashboard</p>
          <h1 className="mt-3 text-3xl font-black uppercase tracking-tight text-slate-100 md:text-5xl">
            Bao cao cham cong ca nhan {data.workerName}
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-7 text-slate-400">
            Dashboard tong hop theo workbook {data.sourceFileName}. Toan bo so lieu gross,
            advance, net, chu cong tac, va lich cong duoc rut tu file Excel goc.
          </p>
        </div>
        <div className="glass-card rounded-3xl p-5">
          <div className="text-xs font-black uppercase tracking-[0.22em] text-slate-500">
            Ky gan nhat
          </div>
          <div className="mt-2 text-2xl font-black text-slate-100">{latestMonth.label}</div>
          <div className="mt-3 text-sm text-slate-400">
            Net {formatCurrency(latestMonth.summary.net)} · {latestMonth.summary.workUnits} cong quy doi
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard
          title="Tong tien cong"
          value={formatCompactCurrency(data.totals.gross)}
          description={`Workbook ${data.year}`}
          icon={Landmark}
          color="emerald"
        />
        <StatCard
          title="Thuc lanh"
          value={formatCompactCurrency(data.totals.net)}
          description="Sau khi tru cac khoan da ung"
          icon={TrendingUp}
          color="sky"
        />
        <StatCard
          title="Cong quy doi"
          value={data.totals.workUnits}
          description={`${data.totals.countO} O / ${data.totals.countN} N / ${data.totals.countX} X`}
          icon={Target}
          color="amber"
        />
        <StatCard
          title="Chu cong tac"
          value={data.owners.length}
          description={bestOwner ? `Top: ${bestOwner.owner}` : "Chua co du lieu"}
          icon={Sparkles}
          color="rose"
        />
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.7fr,1fr]">
        <div className="glass-card rounded-3xl p-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="section-title">Xu huong 12 thang</p>
              <h2 className="mt-2 text-xl font-black text-slate-100">Tien cong va thuc lanh</h2>
            </div>
            <div className="rounded-full bg-white/5 px-4 py-2 text-xs font-bold uppercase text-slate-400">
              Gross vs Net
            </div>
          </div>
          <MonthlyIncomeChart data={monthlyTrend} />
        </div>

        <div className="grid gap-6">
          <div className="glass-card rounded-3xl p-6">
            <p className="section-title">Ty trong cong</p>
            <h2 className="mt-2 text-xl font-black text-slate-100">Co cau O / N / X</h2>
            <AttendanceMixChart data={attendanceMix} />
            <div className="mt-4 grid grid-cols-3 gap-3 text-center">
              {attendanceMix.map((item) => (
                <div key={item.label} className="rounded-2xl bg-white/5 px-3 py-3">
                  <div className="text-[11px] uppercase text-slate-500">{item.label}</div>
                  <div className="mt-1 text-lg font-black text-slate-100">{item.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.2fr,0.8fr]">
        <div className="glass-card rounded-3xl p-6">
          <div className="mb-5">
            <p className="section-title">Owner contribution</p>
            <h2 className="mt-2 text-xl font-black text-slate-100">Dong gop theo chu cong tac</h2>
          </div>
          <OwnerNetChart data={ownerTrend} />
        </div>

        <div className="glass-card rounded-3xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="section-title">Recent activity</p>
              <h2 className="mt-2 text-xl font-black text-slate-100">Ngay cong gan nhat</h2>
            </div>
            <CalendarClock className="h-5 w-5 text-emerald-300" />
          </div>

          <div className="mt-6 space-y-3">
            {latestEntries.map((entry) => (
              <div key={entry.id} className="rounded-2xl border border-white/8 bg-white/5 p-4">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <div className="text-sm font-black uppercase text-slate-100">
                      {entry.owner || "Khong co owner"}
                    </div>
                    <div className="mt-1 text-xs text-slate-500">{entry.date}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-black text-emerald-300">
                      {formatCurrency(entry.net)}
                    </div>
                    <div className="mt-1 text-xs uppercase text-slate-500">{entry.mark || "Trong"}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
