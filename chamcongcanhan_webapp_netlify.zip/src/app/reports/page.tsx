"use client";

import dynamic from "next/dynamic";
import { useMemo } from "react";
import { BadgeDollarSign, BriefcaseBusiness, ClipboardList, Trophy } from "lucide-react";
import StatCard from "@/components/ui/StatCard";
import { useWorkbookData } from "@/components/providers/WorkbookDataProvider";
import { formatCurrency } from "@/lib/utils";

const OwnerNetChart = dynamic(() => import("@/components/charts/OwnerNetChart"), {
  ssr: false,
});
const AttendanceMixChart = dynamic(() => import("@/components/charts/AttendanceMixChart"), {
  ssr: false,
});

export default function ReportsPage() {
  const { data, activeMonths } = useWorkbookData();

  const bestMonth = useMemo(
    () =>
      [...data.months].sort((left, right) => right.summary.net - left.summary.net)[0] ||
      data.months[0],
    [data.months]
  );

  const attendanceMix = useMemo(
    () => [
      { label: "Ca ngay", value: data.totals.countO },
      { label: "Nua ngay", value: data.totals.countN },
      { label: "Nghi", value: data.totals.countX },
    ],
    [data.totals]
  );

  const ownerChart = useMemo(
    () =>
      data.owners.slice(0, 8).map((owner) => ({
        owner: owner.owner,
        net: owner.net,
        gross: owner.gross,
      })),
    [data.owners]
  );

  return (
    <div className="space-y-8">
      <section>
        <p className="section-title">Analyst view</p>
        <h1 className="mt-3 text-3xl font-black uppercase tracking-tight text-slate-100">
          Bao cao tong hop ca nam
        </h1>
        <p className="mt-3 max-w-2xl text-slate-400">
          Goc nhin tong hop ve owner, thang co hieu suat cao, va matrix gross / advance / net
          cua toan bo workbook.
        </p>
      </section>

      <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard
          title="Best month"
          value={bestMonth.label}
          description={formatCurrency(bestMonth.summary.net)}
          icon={Trophy}
          color="emerald"
        />
        <StatCard
          title="Active months"
          value={activeMonths.length}
          description="So thang co phat sinh du lieu"
          icon={ClipboardList}
          color="sky"
        />
        <StatCard
          title="Top owner"
          value={data.owners[0]?.owner || "Chua co"}
          description={data.owners[0] ? formatCurrency(data.owners[0].net) : "0"}
          icon={BriefcaseBusiness}
          color="amber"
        />
        <StatCard
          title="Tong gross"
          value={formatCurrency(data.totals.gross)}
          description={`Advance ${formatCurrency(data.totals.advance)}`}
          icon={BadgeDollarSign}
          color="rose"
        />
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.1fr,0.9fr]">
        <div className="glass-card rounded-3xl p-6">
          <p className="section-title">Owner ranking</p>
          <h2 className="mt-2 text-xl font-black text-slate-100">Xep hang owner theo net</h2>
          <OwnerNetChart data={ownerChart} />
        </div>
        <div className="glass-card rounded-3xl p-6">
          <p className="section-title">Attendance distribution</p>
          <h2 className="mt-2 text-xl font-black text-slate-100">Co cau cong ca nam</h2>
          <AttendanceMixChart data={attendanceMix} />
          <div className="mt-4 grid grid-cols-3 gap-3 text-center">
            {attendanceMix.map((item) => (
              <div key={item.label} className="rounded-2xl bg-white/5 p-3">
                <div className="text-[11px] uppercase text-slate-500">{item.label}</div>
                <div className="mt-1 text-lg font-black text-slate-100">{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.1fr,0.9fr]">
        <div className="glass-card overflow-hidden rounded-3xl">
          <div className="border-b border-white/10 px-6 py-5">
            <p className="section-title">Monthly matrix</p>
            <h2 className="mt-2 text-xl font-black text-slate-100">Tong hop theo thang</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="bg-white/5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">
                <tr>
                  <th className="px-6 py-4">Thang</th>
                  <th className="px-6 py-4 text-right">Cong</th>
                  <th className="px-6 py-4 text-right">Gross</th>
                  <th className="px-6 py-4 text-right">Advance</th>
                  <th className="px-6 py-4 text-right">Net</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {data.months.map((month) => (
                  <tr key={month.id} className="hover:bg-white/5">
                    <td className="px-6 py-4 font-black text-slate-100">{month.label}</td>
                    <td className="px-6 py-4 text-right text-slate-300">{month.summary.workUnits}</td>
                    <td className="px-6 py-4 text-right text-slate-100">{formatCurrency(month.summary.gross)}</td>
                    <td className="px-6 py-4 text-right text-amber-300">{formatCurrency(month.summary.advance)}</td>
                    <td className="px-6 py-4 text-right font-black text-emerald-300">{formatCurrency(month.summary.net)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="glass-card rounded-3xl p-6">
          <p className="section-title">Owner ledger</p>
          <h2 className="mt-2 text-xl font-black text-slate-100">Tong ket theo owner</h2>
          <div className="mt-5 space-y-3">
            {data.owners.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/10 bg-white/5 p-4 text-sm text-slate-400">
                Workbook hien chua co owner active nao.
              </div>
            ) : (
              data.owners.map((owner) => (
                <div key={owner.owner} className="rounded-2xl border border-white/8 bg-white/5 p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="font-black uppercase text-slate-100">{owner.owner}</div>
                      <div className="mt-1 text-xs text-slate-500">
                        {owner.daysWorked} ngay · {owner.workUnits} cong quy doi
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-black text-emerald-300">{formatCurrency(owner.net)}</div>
                      <div className="mt-1 text-xs text-slate-500">Gross {formatCurrency(owner.gross)}</div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
