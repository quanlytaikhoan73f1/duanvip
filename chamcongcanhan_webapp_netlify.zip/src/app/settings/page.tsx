"use client";

import { useEffect, useRef, useState } from "react";
import {
  Database,
  FileSpreadsheet,
  HardDriveDownload,
  RefreshCcw,
  ShieldCheck,
  Upload,
} from "lucide-react";
import StatCard from "@/components/ui/StatCard";
import { useWorkbookData } from "@/components/providers/WorkbookDataProvider";
import { formatCurrency } from "@/lib/utils";

export default function SettingsPage() {
  const {
    data,
    activeMonths,
    hasCustomData,
    importError,
    isImporting,
    importWorkbook,
    resetWorkbook,
    updateProfile,
  } = useWorkbookData();
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [profile, setProfile] = useState({
    workerName: data.workerName,
    sourceFileName: data.sourceFileName,
    year: String(data.year),
  });

  useEffect(() => {
    setProfile({
      workerName: data.workerName,
      sourceFileName: data.sourceFileName,
      year: String(data.year),
    });
  }, [data.sourceFileName, data.workerName, data.year]);

  async function handleFileChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      await importWorkbook(file);
    } finally {
      event.target.value = "";
    }
  }

  return (
    <div className="space-y-8">
      <section className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-3xl">
          <p className="section-title">Data control</p>
          <h1 className="mt-3 text-3xl font-black uppercase tracking-tight text-slate-100 md:text-5xl">
            Quan ly workbook Excel
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-7 text-slate-400">
            Ngoai viec import file Excel moi, trang nay cho phep sua thong tin hien thi cua ho
            so va luu lai ngay trong app.
          </p>
        </div>

        <div className="glass-card rounded-3xl p-5">
          <div className="text-xs font-black uppercase tracking-[0.22em] text-slate-500">
            Trang thai hien tai
          </div>
          <div className="mt-2 text-2xl font-black text-slate-100">
            {hasCustomData ? "Dang dung file da import" : "Dang dung file seed mac dinh"}
          </div>
          <div className="mt-3 text-sm text-slate-400">
            Source: {data.sourceFileName} / {data.year}
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard
          title="Nguon du lieu"
          value={hasCustomData ? "Custom file" : "Seed file"}
          description={data.sourceFileName}
          icon={Database}
          color="emerald"
        />
        <StatCard
          title="Thang active"
          value={activeMonths.length}
          description="So thang co phat sinh du lieu"
          icon={FileSpreadsheet}
          color="sky"
        />
        <StatCard
          title="Tong net"
          value={formatCurrency(data.totals.net)}
          description="Gia tri sau khi tru da ung"
          icon={ShieldCheck}
          color="amber"
        />
        <StatCard
          title="Cap nhat luc"
          value={new Date(data.generatedAt).toLocaleDateString("vi-VN")}
          description="Theo timestamp trong dataset"
          icon={RefreshCcw}
          color="rose"
        />
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.15fr,0.85fr]">
        <div className="glass-card rounded-3xl p-6">
          <p className="section-title">Import workbook</p>
          <h2 className="mt-2 text-xl font-black text-slate-100">
            Nap file Excel moi vao dashboard
          </h2>
          <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-400">
            Chon file `.xlsx` co cau truc giong workbook mau. App se parse cac sheet thang,
            tinh lai gross, advance, net, owner, va lam moi toan bo dashboard ngay lap tuc.
          </p>

          <input
            ref={inputRef}
            type="file"
            accept=".xlsx,.xlsm,.xls"
            className="hidden"
            onChange={handleFileChange}
          />

          <div className="mt-6 flex flex-col gap-3 md:flex-row">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              disabled={isImporting}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-emerald-400 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] text-slate-950 transition hover:bg-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <Upload className="h-4 w-4" />
              {isImporting ? "Dang import..." : "Import file Excel"}
            </button>

            <a
              href="/source/So_Cham_Cong_Cuong.xlsx"
              download
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] text-slate-100 transition hover:bg-white/10"
            >
              <HardDriveDownload className="h-4 w-4" />
              Tai file mau
            </a>

            <button
              type="button"
              onClick={resetWorkbook}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-rose-500/30 bg-rose-500/10 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] text-rose-200 transition hover:bg-rose-500/20"
            >
              <RefreshCcw className="h-4 w-4" />
              Reset ve file seed
            </button>
          </div>

          {importError ? (
            <div className="mt-4 rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
              {importError}
            </div>
          ) : null}

          <div className="mt-6 rounded-3xl border border-white/10 bg-slate-950/40 p-5">
            <div className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
              Yeu cau workbook
            </div>
            <ul className="mt-4 space-y-3 text-sm leading-7 text-slate-300">
              <li>Can co cac sheet thang nhu `Thang 1` den `Thang 12`.</li>
              <li>Bang ngay cong can giu cot ngay, owner, loai cong, don gia, gross, advance, net.</li>
              <li>Sau khi import, du lieu duoc luu trong trinh duyet hien tai.</li>
            </ul>
          </div>
        </div>

        <div className="space-y-6">
          <div className="glass-card rounded-3xl p-6">
            <p className="section-title">Profile editor</p>
            <h2 className="mt-2 text-xl font-black text-slate-100">Sua thong tin workbook</h2>

            <div className="mt-5 space-y-4">
              <label className="block">
                <div className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                  Ten nguoi lao dong
                </div>
                <input
                  value={profile.workerName}
                  onChange={(event) =>
                    setProfile((current) => ({ ...current, workerName: event.target.value }))
                  }
                  className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-100 outline-none transition focus:border-emerald-400/50 focus:bg-white/8"
                />
              </label>

              <label className="block">
                <div className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                  Ten file hien thi
                </div>
                <input
                  value={profile.sourceFileName}
                  onChange={(event) =>
                    setProfile((current) => ({ ...current, sourceFileName: event.target.value }))
                  }
                  className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-100 outline-none transition focus:border-emerald-400/50 focus:bg-white/8"
                />
              </label>

              <label className="block">
                <div className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                  Nam lam viec
                </div>
                <input
                  type="number"
                  value={profile.year}
                  onChange={(event) =>
                    setProfile((current) => ({ ...current, year: event.target.value }))
                  }
                  className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-100 outline-none transition focus:border-emerald-400/50 focus:bg-white/8"
                />
              </label>
            </div>

            <button
              type="button"
              onClick={() =>
                updateProfile({
                  workerName: profile.workerName,
                  sourceFileName: profile.sourceFileName,
                  year: Number(profile.year || data.year),
                })
              }
              className="mt-6 inline-flex items-center justify-center gap-2 rounded-2xl bg-sky-400 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] text-slate-950 transition hover:bg-sky-300"
            >
              <Database className="h-4 w-4" />
              Luu thong tin workbook
            </button>
          </div>

          <div className="glass-card rounded-3xl p-6">
            <p className="section-title">Workbook snapshot</p>
            <h2 className="mt-2 text-xl font-black text-slate-100">Thong tin dataset dang dung</h2>

            <div className="mt-5 space-y-3">
              <div className="rounded-2xl bg-white/5 p-4">
                <div className="text-xs uppercase text-slate-500">Ten nguon</div>
                <div className="mt-2 text-lg font-black text-slate-100">{data.sourceFileName}</div>
              </div>
              <div className="rounded-2xl bg-white/5 p-4">
                <div className="text-xs uppercase text-slate-500">Nguoi lao dong</div>
                <div className="mt-2 text-lg font-black text-slate-100">{data.workerName}</div>
              </div>
              <div className="rounded-2xl bg-white/5 p-4">
                <div className="text-xs uppercase text-slate-500">Tong cong quy doi</div>
                <div className="mt-2 text-lg font-black text-slate-100">{data.totals.workUnits}</div>
              </div>
              <div className="rounded-2xl bg-white/5 p-4">
                <div className="text-xs uppercase text-slate-500">Tong owner</div>
                <div className="mt-2 text-lg font-black text-slate-100">{data.owners.length}</div>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-3xl p-6">
            <p className="section-title">Deploy note</p>
            <h2 className="mt-2 text-xl font-black text-slate-100">Goi y khi dua len Netlify</h2>
            <div className="mt-4 space-y-3 text-sm leading-7 text-slate-300">
              <p>Ban nay da dung san workbook seed nen sau khi deploy se hien dashboard ngay.</p>
              <p>
                Neu muon thay file moi sau khi len mang, vao trang nay va bam `Import file Excel`.
              </p>
              <p>
                Neu muon sua tay tung ngay cong va thong tin ho so, ban co the lam truc tiep
                trong app ma khong can sua file Excel goc.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
