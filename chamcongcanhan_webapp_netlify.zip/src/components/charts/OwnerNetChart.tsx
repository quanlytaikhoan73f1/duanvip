"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { formatCurrency } from "@/lib/utils";

export default function OwnerNetChart({
  data,
}: {
  data: Array<{ owner: string; net: number; gross: number }>;
}) {
  return (
    <div className="h-[320px] min-h-[320px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 8, right: 16 }}>
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#ffffff12" />
          <XAxis
            type="number"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "#94a3b8", fontSize: 12 }}
            tickFormatter={(value) => `${Math.round(Number(value) / 1000)}k`}
          />
          <YAxis
            type="category"
            dataKey="owner"
            width={120}
            axisLine={false}
            tickLine={false}
            tick={{ fill: "#cbd5e1", fontSize: 12 }}
          />
          <Tooltip
            formatter={(value) => formatCurrency(Number(value || 0))}
            contentStyle={{
              backgroundColor: "#0f172a",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 18,
              color: "#f8fafc",
            }}
          />
          <Bar dataKey="net" fill="#f59e0b" radius={[0, 10, 10, 0]} name="Thuc lanh" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
