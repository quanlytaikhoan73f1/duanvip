"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  CalendarDays,
  Database,
  LayoutDashboard,
  WalletCards,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useWorkbookData } from "../providers/WorkbookDataProvider";

const navItems = [
  { name: "Tong quan", href: "/", icon: LayoutDashboard },
  { name: "Cham cong", href: "/attendance", icon: CalendarDays },
  { name: "Dong tien", href: "/finance", icon: WalletCards },
  { name: "Bao cao", href: "/reports", icon: BarChart3 },
  { name: "Du lieu", href: "/settings", icon: Database },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { data, latestMonth } = useWorkbookData();

  return (
    <aside className="fixed inset-x-0 bottom-0 z-50 border-t border-white/10 bg-slate-900/85 backdrop-blur md:sticky md:top-0 md:h-screen md:w-72 md:border-r md:border-t-0">
      <div className="flex h-full flex-col justify-between px-3 py-3 md:px-5 md:py-8">
        <div>
          <div className="mb-8 hidden md:block">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-5">
              <p className="text-xs font-black uppercase tracking-[0.28em] text-emerald-300">
                Personal Ops
              </p>
              <h1 className="mt-3 text-2xl font-black uppercase tracking-tight text-slate-100">
                {data.workerName}
              </h1>
              <p className="mt-2 text-sm text-slate-400">
                Workbook {data.year} · update den {latestMonth.label}
              </p>
            </div>
          </div>

          <nav className="grid grid-cols-5 gap-1 md:grid-cols-1 md:gap-2">
            {navItems.map((item) => {
              const isActive = pathname === item.href;
              const Icon = item.icon;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center justify-center gap-2 rounded-2xl px-2 py-3 text-center text-[11px] font-bold transition-all md:justify-start md:px-4 md:text-sm",
                    isActive
                      ? "bg-emerald-500/15 text-emerald-300 shadow-[0_0_30px_rgba(16,185,129,0.12)]"
                      : "text-slate-400 hover:bg-white/5 hover:text-slate-100"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span className="hidden md:inline">{item.name}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="hidden rounded-3xl border border-white/10 bg-gradient-to-br from-emerald-500/12 to-sky-500/12 p-5 md:block">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-sky-300">Snapshot</p>
          <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-2xl bg-slate-950/50 p-3">
              <div className="text-[10px] uppercase text-slate-500">Tong net</div>
              <div className="mt-1 font-black text-slate-100">{data.totals.net.toLocaleString()}</div>
            </div>
            <div className="rounded-2xl bg-slate-950/50 p-3">
              <div className="text-[10px] uppercase text-slate-500">So chu</div>
              <div className="mt-1 font-black text-slate-100">{data.owners.length}</div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
