"use client";

import { useMemo, useState } from "react";
import { Eraser, Save } from "lucide-react";
import { AttendanceMark, WorkbookEntry } from "@/lib/types";
import { calculateEntryAmounts } from "@/lib/workbook";
import { formatCurrency } from "@/lib/utils";

type EntryEditorValues = {
  owner: string;
  mark: AttendanceMark;
  unitPrice: string;
  advance: string;
};

export default function AttendanceEntryEditor({
  entry,
  monthLabel,
  onSave,
  onClear,
}: {
  entry: WorkbookEntry;
  monthLabel: string;
  onSave: (values: { owner: string; mark: AttendanceMark; unitPrice: number; advance: number }) => void;
  onClear: () => void;
}) {
  const [form, setForm] = useState<EntryEditorValues>({
    owner: entry.owner,
    mark: entry.mark,
    unitPrice: String(entry.unitPrice || 0),
    advance: String(entry.advance || 0),
  });

  const preview = useMemo(
    () => calculateEntryAmounts(form.mark, Number(form.unitPrice || 0), Number(form.advance || 0)),
    [form.advance, form.mark, form.unitPrice]
  );

  return (
    <div className="glass-card rounded-3xl p-6">
      <p className="section-title">Entry editor</p>
      <h2 className="mt-2 text-xl font-black text-slate-100">
        Sua ngay {entry.day} / {monthLabel}
      </h2>
      <p className="mt-3 text-sm leading-7 text-slate-400">
        Chon mot dong trong bang de nhap moi hoac chinh sua. Gross va net duoc tinh lai tu
        loai cong, don gia, va tien da ung.
      </p>

      <div className="mt-6 space-y-4">
        <label className="block">
          <div className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
            Chu / cho lam
          </div>
          <input
            value={form.owner}
            onChange={(event) => setForm((current) => ({ ...current, owner: event.target.value }))}
            className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-100 outline-none transition focus:border-emerald-400/50 focus:bg-white/8"
            placeholder="Vi du: Dung Lukang"
          />
        </label>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <label className="block">
            <div className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
              Loai cong
            </div>
            <select
              value={form.mark}
              onChange={(event) =>
                setForm((current) => ({
                  ...current,
                  mark: event.target.value as AttendanceMark,
                }))
              }
              className="w-full rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-100 outline-none transition focus:border-emerald-400/50"
            >
              <option value="">Chon</option>
              <option value="O">Ca ngay (O)</option>
              <option value="N">Nua ngay (N)</option>
              <option value="X">Nghi (X)</option>
            </select>
          </label>

          <label className="block">
            <div className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
              Don gia
            </div>
            <input
              type="number"
              min="0"
              value={form.unitPrice}
              onChange={(event) =>
                setForm((current) => ({ ...current, unitPrice: event.target.value }))
              }
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-100 outline-none transition focus:border-emerald-400/50 focus:bg-white/8"
            />
          </label>
        </div>

        <label className="block">
          <div className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
            Da ung
          </div>
          <input
            type="number"
            min="0"
            value={form.advance}
            onChange={(event) => setForm((current) => ({ ...current, advance: event.target.value }))}
            className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-100 outline-none transition focus:border-emerald-400/50 focus:bg-white/8"
          />
        </label>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3">
        <div className="rounded-2xl bg-white/5 p-4">
          <div className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">
            Gross preview
          </div>
          <div className="mt-2 text-lg font-black text-slate-100">
            {formatCurrency(preview.wage)}
          </div>
        </div>
        <div className="rounded-2xl bg-white/5 p-4">
          <div className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">
            Net preview
          </div>
          <div className="mt-2 text-lg font-black text-emerald-300">
            {formatCurrency(preview.net)}
          </div>
        </div>
      </div>

      <div className="mt-6 flex flex-col gap-3 md:flex-row">
        <button
          type="button"
          onClick={() =>
            onSave({
              owner: form.owner,
              mark: form.mark,
              unitPrice: Number(form.unitPrice || 0),
              advance: Number(form.advance || 0),
            })
          }
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-emerald-400 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] text-slate-950 transition hover:bg-emerald-300"
        >
          <Save className="h-4 w-4" />
          Luu ngay nay
        </button>
        <button
          type="button"
          onClick={onClear}
          className="inline-flex items-center justify-center gap-2 rounded-2xl border border-rose-500/30 bg-rose-500/10 px-5 py-3 text-sm font-black uppercase tracking-[0.16em] text-rose-200 transition hover:bg-rose-500/20"
        >
          <Eraser className="h-4 w-4" />
          Xoa du lieu
        </button>
      </div>
    </div>
  );
}
