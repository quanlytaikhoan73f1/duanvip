"use client";

import { WorkbookEntry } from "@/lib/types";
import { cn, formatAttendanceMark, formatCurrency, getMarkBadgeClass } from "@/lib/utils";

export default function MonthAttendanceTable({
  entries,
  showEmptyDays,
  selectedEntryId,
  onSelectEntry,
}: {
  entries: WorkbookEntry[];
  showEmptyDays: boolean;
  selectedEntryId: string;
  onSelectEntry: (entry: WorkbookEntry) => void;
}) {
  const visibleEntries = showEmptyDays ? entries : entries.filter((entry) => entry.hasActivity);

  return (
    <div className="overflow-hidden rounded-3xl border border-white/10 bg-slate-900/35">
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-white/5 text-[11px] font-black uppercase tracking-[0.18em] text-slate-500">
            <tr>
              <th className="px-5 py-4">Ngay</th>
              <th className="px-5 py-4">Chu / Cho lam</th>
              <th className="px-5 py-4">Loai cong</th>
              <th className="px-5 py-4 text-right">Don gia</th>
              <th className="px-5 py-4 text-right">Tien cong</th>
              <th className="px-5 py-4 text-right">Da ung</th>
              <th className="px-5 py-4 text-right">Thuc lanh</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {visibleEntries.map((entry) => (
              <tr
                key={entry.id}
                onClick={() => onSelectEntry(entry)}
                className={cn(
                  "cursor-pointer transition-colors hover:bg-white/5",
                  entry.hasActivity ? "bg-white/[0.02]" : "text-slate-500",
                  selectedEntryId === entry.id && "bg-emerald-500/12 ring-1 ring-inset ring-emerald-400/40"
                )}
              >
                <td className="px-5 py-4 font-mono text-slate-300">
                  {entry.date.slice(8, 10)}/{entry.date.slice(5, 7)}
                </td>
                <td className="px-5 py-4">
                  <div className="font-bold text-slate-100">{entry.owner || "Chua co du lieu"}</div>
                  <div className="text-xs text-slate-500">{entry.date}</div>
                </td>
                <td className="px-5 py-4">
                  <span
                    className={cn(
                      "inline-flex min-w-24 items-center justify-center rounded-full border px-3 py-1 text-xs font-black uppercase",
                      getMarkBadgeClass(entry.mark)
                    )}
                  >
                    {formatAttendanceMark(entry.mark)}
                  </span>
                </td>
                <td className="px-5 py-4 text-right font-semibold text-slate-200">
                  {entry.unitPrice ? formatCurrency(entry.unitPrice) : "0"}
                </td>
                <td className="px-5 py-4 text-right font-semibold text-slate-100">
                  {formatCurrency(entry.wage)}
                </td>
                <td className="px-5 py-4 text-right font-semibold text-amber-300">
                  {formatCurrency(entry.advance)}
                </td>
                <td className="px-5 py-4 text-right font-black text-emerald-300">
                  {formatCurrency(entry.net)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
