"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { AttendanceMark, PersonalWorkbookData } from "@/lib/types";
import {
  WORKBOOK_STORAGE_KEY,
  buildMonthOwnerSummary,
  bundledWorkbookData,
  clearWorkbookEntry,
  getActiveMonths,
  getLatestActiveMonth,
  normalizeWorkbookData,
  parseWorkbookArrayBuffer,
  updateWorkbookEntry,
  updateWorkbookProfile,
} from "@/lib/workbook";

type WorkbookContextValue = {
  data: PersonalWorkbookData;
  activeMonths: PersonalWorkbookData["months"];
  latestMonth: PersonalWorkbookData["months"][number];
  hasCustomData: boolean;
  isImporting: boolean;
  importError: string | null;
  importWorkbook: (file: File) => Promise<void>;
  resetWorkbook: () => void;
  saveEntry: (
    monthId: string,
    day: number,
    values: { owner: string; mark: AttendanceMark; unitPrice: number; advance: number }
  ) => void;
  clearEntry: (monthId: string, day: number) => void;
  updateProfile: (values: { workerName: string; sourceFileName: string; year: number }) => void;
  getMonthOwnerSummary: (monthId: string) => ReturnType<typeof buildMonthOwnerSummary>;
};

const WorkbookContext = createContext<WorkbookContextValue | null>(null);

export function WorkbookDataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<PersonalWorkbookData>(bundledWorkbookData);
  const [hasCustomData, setHasCustomData] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem(WORKBOOK_STORAGE_KEY);
    if (!stored) return;

    try {
      const parsed = normalizeWorkbookData(JSON.parse(stored) as PersonalWorkbookData);
      setData(parsed);
      setHasCustomData(true);
    } catch (error) {
      console.error("Failed to hydrate workbook data:", error);
      localStorage.removeItem(WORKBOOK_STORAGE_KEY);
    }
  }, []);

  const activeMonths = useMemo(() => getActiveMonths(data), [data]);
  const latestMonth = useMemo(() => getLatestActiveMonth(data), [data]);

  function persistWorkbook(nextData: PersonalWorkbookData, markAsCustom = true) {
    setData(nextData);
    setHasCustomData(markAsCustom);
    setImportError(null);
    localStorage.setItem(WORKBOOK_STORAGE_KEY, JSON.stringify(nextData));
  }

  const value = useMemo<WorkbookContextValue>(
    () => ({
      data,
      activeMonths,
      latestMonth,
      hasCustomData,
      isImporting,
      importError,
      importWorkbook: async (file: File) => {
        setIsImporting(true);
        setImportError(null);

        try {
          const buffer = await file.arrayBuffer();
          const nextData = parseWorkbookArrayBuffer(buffer, file.name);
          persistWorkbook(nextData);
        } catch (error) {
          console.error(error);
          setImportError("Khong doc duoc workbook. Kiem tra lai file Excel.");
          throw error;
        } finally {
          setIsImporting(false);
        }
      },
      resetWorkbook: () => {
        localStorage.removeItem(WORKBOOK_STORAGE_KEY);
        setData(bundledWorkbookData);
        setHasCustomData(false);
        setImportError(null);
      },
      saveEntry: (monthId, day, values) => {
        const nextData = updateWorkbookEntry(data, monthId, day, values);
        persistWorkbook(nextData);
      },
      clearEntry: (monthId, day) => {
        const nextData = clearWorkbookEntry(data, monthId, day);
        persistWorkbook(nextData);
      },
      updateProfile: (values) => {
        const nextData = updateWorkbookProfile(data, values);
        persistWorkbook(nextData);
      },
      getMonthOwnerSummary: (monthId: string) => {
        const month = data.months.find((item) => item.id === monthId) || latestMonth;
        return buildMonthOwnerSummary(month);
      },
    }),
    [activeMonths, data, hasCustomData, importError, isImporting, latestMonth]
  );

  return <WorkbookContext.Provider value={value}>{children}</WorkbookContext.Provider>;
}

export function useWorkbookData() {
  const context = useContext(WorkbookContext);
  if (!context) {
    throw new Error("useWorkbookData must be used within WorkbookDataProvider");
  }
  return context;
}
