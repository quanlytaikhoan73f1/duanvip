export type AttendanceMark = "O" | "N" | "X" | "";

export interface WorkbookEntry {
  id: string;
  date: string;
  day: number;
  owner: string;
  mark: AttendanceMark;
  unitPrice: number;
  wage: number;
  advance: number;
  net: number;
  hasActivity: boolean;
}

export interface MonthSummary {
  countO: number;
  countN: number;
  countX: number;
  gross: number;
  advance: number;
  net: number;
  workUnits: number;
}

export interface MonthData {
  id: string;
  label: string;
  monthNumber: number;
  summary: MonthSummary;
  entries: WorkbookEntry[];
}

export interface OwnerSummary {
  owner: string;
  workUnits: number;
  countO: number;
  countN: number;
  countX: number;
  gross: number;
  advance: number;
  net: number;
  daysWorked: number;
}

export interface WorkbookTotals {
  gross: number;
  advance: number;
  net: number;
  workUnits: number;
  countO: number;
  countN: number;
  countX: number;
}

export interface PersonalWorkbookData {
  workerName: string;
  year: number;
  currency: string;
  sourceFileName: string;
  generatedAt: string;
  totals: WorkbookTotals;
  months: MonthData[];
  owners: OwnerSummary[];
}
