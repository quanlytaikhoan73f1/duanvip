import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number) {
  return new Intl.NumberFormat("zh-TW", {
    style: "currency",
    currency: "TWD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function formatCompactCurrency(value: number) {
  return new Intl.NumberFormat("zh-TW", {
    style: "currency",
    currency: "TWD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
    notation: "compact",
  }).format(value);
}

export function formatMonthLabel(monthNumber: number) {
  return `Thang ${monthNumber}`;
}

export function formatAttendanceMark(mark: string) {
  if (mark === "O") return "Ca ngay";
  if (mark === "N") return "Nua ngay";
  if (mark === "X") return "Nghi";
  return "Trong";
}

export function getMarkBadgeClass(mark: string) {
  if (mark === "O") return "bg-emerald-500/15 text-emerald-300 border-emerald-500/30";
  if (mark === "N") return "bg-amber-500/15 text-amber-300 border-amber-500/30";
  if (mark === "X") return "bg-rose-500/15 text-rose-300 border-rose-500/30";
  return "bg-white/5 text-slate-400 border-white/10";
}

export function slugifyOwner(owner: string) {
  return owner
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}
