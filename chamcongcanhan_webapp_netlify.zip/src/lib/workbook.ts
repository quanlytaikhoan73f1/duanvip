"use client";

import * as XLSX from "xlsx";
import seed from "@/data/personal-workbook-seed.json";
import {
  AttendanceMark,
  MonthData,
  OwnerSummary,
  PersonalWorkbookData,
  WorkbookEntry,
} from "./types";
import { formatMonthLabel } from "./utils";

export const WORKBOOK_STORAGE_KEY = "personal-attendance-workbook-v1";

const rawSeed = seed as PersonalWorkbookData;

function inferWorkerName(sourceFileName: string) {
  const cleaned = sourceFileName
    .replace(/\.[^.]+$/, "")
    .replace(/^so[_\s-]*cham[_\s-]*cong[_\s-]*/i, "")
    .replace(/[_-]+/g, " ")
    .trim();

  return cleaned || "Ca nhan";
}

function parseMonthNumber(title: string) {
  const match = title.match(/(\d+)/);
  return match ? Number(match[1]) : 1;
}

function parseExcelDate(value: unknown, year: number, monthNumber: number, day: number) {
  if (value instanceof Date) {
    return value.toISOString().slice(0, 10);
  }

  if (typeof value === "number") {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed) {
      return new Date(Date.UTC(parsed.y, parsed.m - 1, parsed.d)).toISOString().slice(0, 10);
    }
  }

  if (typeof value === "string" && value.trim()) {
    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime())) {
      return parsed.toISOString().slice(0, 10);
    }
  }

  return new Date(Date.UTC(year, monthNumber - 1, day)).toISOString().slice(0, 10);
}

function daysInMonth(year: number, monthNumber: number) {
  return new Date(year, monthNumber, 0).getDate();
}

function normalizeMark(mark: unknown): AttendanceMark {
  if (mark === "O" || mark === "N" || mark === "X") {
    return mark;
  }

  return "";
}

function normalizeNumber(value: unknown) {
  const numeric = Number(value ?? 0);
  return Number.isFinite(numeric) ? numeric : 0;
}

export function calculateEntryAmounts(mark: AttendanceMark, unitPrice: number, advance: number) {
  const normalizedUnitPrice = normalizeNumber(unitPrice);
  const normalizedAdvance = normalizeNumber(advance);
  const wage =
    mark === "O" ? normalizedUnitPrice : mark === "N" ? normalizedUnitPrice * 0.5 : 0;

  return {
    unitPrice: normalizedUnitPrice,
    advance: normalizedAdvance,
    wage,
    net: wage - normalizedAdvance,
  };
}

function buildEmptyEntry(year: number, monthNumber: number, day: number): WorkbookEntry {
  return {
    id: `${year}-${String(monthNumber).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
    date: new Date(Date.UTC(year, monthNumber - 1, day)).toISOString().slice(0, 10),
    day,
    owner: "",
    mark: "",
    unitPrice: 0,
    wage: 0,
    advance: 0,
    net: 0,
    hasActivity: false,
  };
}

function createMonthEntries(sheet: XLSX.WorkSheet | undefined, year: number, monthNumber: number) {
  return Array.from({ length: daysInMonth(year, monthNumber) }, (_, index) => {
    const day = index + 1;
    const row = day + 1;
    const base = buildEmptyEntry(year, monthNumber, day);

    if (!sheet) {
      return base;
    }

    const owner = String(sheet[`B${row}`]?.v || "").trim();
    const markRaw = String(sheet[`C${row}`]?.v || "").trim().toUpperCase();
    const mark = normalizeMark(markRaw);
    const unitPrice = normalizeNumber(sheet[`D${row}`]?.v || 0);
    const wage = normalizeNumber(sheet[`E${row}`]?.v || 0);
    const advance = normalizeNumber(sheet[`F${row}`]?.v || 0);
    const net = normalizeNumber(sheet[`G${row}`]?.v || 0);
    const rawDate = sheet[`A${row}`]?.v;

    return {
      ...base,
      date: parseExcelDate(rawDate, year, monthNumber, day),
      owner,
      mark,
      unitPrice,
      wage,
      advance,
      net,
      hasActivity: Boolean(owner || mark || unitPrice || wage || advance || net),
    };
  });
}

function summarizeEntries(entries: WorkbookEntry[]) {
  const activeEntries = entries.filter((entry) => entry.hasActivity);
  const countO = activeEntries.filter((entry) => entry.mark === "O").length;
  const countN = activeEntries.filter((entry) => entry.mark === "N").length;
  const countX = activeEntries.filter((entry) => entry.mark === "X").length;
  const gross = activeEntries.reduce((sum, entry) => sum + entry.wage, 0);
  const advance = activeEntries.reduce((sum, entry) => sum + entry.advance, 0);
  const net = activeEntries.reduce((sum, entry) => sum + entry.net, 0);

  return {
    countO,
    countN,
    countX,
    gross,
    advance,
    net,
    workUnits: countO + countN * 0.5,
  };
}

function computeOwnerSummaries(months: MonthData[]): OwnerSummary[] {
  const ownerMap = new Map<string, OwnerSummary>();

  for (const month of months) {
    for (const entry of month.entries) {
      if (!entry.hasActivity || !entry.owner) continue;

      const current = ownerMap.get(entry.owner) || {
        owner: entry.owner,
        workUnits: 0,
        countO: 0,
        countN: 0,
        countX: 0,
        gross: 0,
        advance: 0,
        net: 0,
        daysWorked: 0,
      };

      if (entry.mark === "O") {
        current.workUnits += 1;
        current.countO += 1;
        current.daysWorked += 1;
      } else if (entry.mark === "N") {
        current.workUnits += 0.5;
        current.countN += 1;
        current.daysWorked += 1;
      } else if (entry.mark === "X") {
        current.countX += 1;
      }

      current.gross += entry.wage;
      current.advance += entry.advance;
      current.net += entry.net;

      ownerMap.set(entry.owner, current);
    }
  }

  return [...ownerMap.values()].sort((left, right) => right.net - left.net);
}

function normalizeMonth(month: MonthData, year: number): MonthData {
  const monthNumber = month.monthNumber || parseMonthNumber(month.label);
  const entries =
    month.entries?.map((entry, index) => {
      const day = entry.day || index + 1;
      const base = buildEmptyEntry(year, monthNumber, day);

      return {
        ...base,
        ...entry,
        id: base.id,
        date: base.date,
        day,
        owner: entry.owner || "",
        mark: normalizeMark(entry.mark),
        unitPrice: normalizeNumber(entry.unitPrice || 0),
        wage: normalizeNumber(entry.wage || 0),
        advance: normalizeNumber(entry.advance || 0),
        net: normalizeNumber(entry.net || 0),
        hasActivity: Boolean(
          entry.hasActivity ||
            entry.owner ||
            entry.mark ||
            entry.unitPrice ||
            entry.wage ||
            entry.advance ||
            entry.net
        ),
      };
    }) || [];

  const computedSummary = summarizeEntries(entries);

  return {
    id: month.id || `${year}-${String(monthNumber).padStart(2, "0")}`,
    label: formatMonthLabel(monthNumber),
    monthNumber,
    summary: {
      countO: Number(month.summary?.countO ?? computedSummary.countO),
      countN: Number(month.summary?.countN ?? computedSummary.countN),
      countX: Number(month.summary?.countX ?? computedSummary.countX),
      gross: Number(month.summary?.gross ?? computedSummary.gross),
      advance: Number(month.summary?.advance ?? computedSummary.advance),
      net: Number(month.summary?.net ?? computedSummary.net),
      workUnits: Number(month.summary?.workUnits ?? computedSummary.workUnits),
    },
    entries,
  };
}

export function normalizeWorkbookData(data: PersonalWorkbookData): PersonalWorkbookData {
  const year = Number(data.year || new Date().getUTCFullYear());
  const months = Array.from({ length: 12 }, (_, index) => {
    const monthNumber = index + 1;
    const sourceMonth = data.months.find((month) => month.monthNumber === monthNumber);

    if (sourceMonth) {
      return normalizeMonth(sourceMonth, year);
    }

    return normalizeMonth(
      {
        id: `${year}-${String(monthNumber).padStart(2, "0")}`,
        label: formatMonthLabel(monthNumber),
        monthNumber,
        summary: {
          countO: 0,
          countN: 0,
          countX: 0,
          gross: 0,
          advance: 0,
          net: 0,
          workUnits: 0,
        },
        entries: Array.from({ length: daysInMonth(year, monthNumber) }, (_, dayIndex) =>
          buildEmptyEntry(year, monthNumber, dayIndex + 1)
        ),
      },
      year
    );
  });

  const owners = computeOwnerSummaries(months);
  const totals = {
    gross: months.reduce((sum, month) => sum + month.summary.gross, 0),
    advance: months.reduce((sum, month) => sum + month.summary.advance, 0),
    net: months.reduce((sum, month) => sum + month.summary.net, 0),
    workUnits: months.reduce((sum, month) => sum + month.summary.workUnits, 0),
    countO: months.reduce((sum, month) => sum + month.summary.countO, 0),
    countN: months.reduce((sum, month) => sum + month.summary.countN, 0),
    countX: months.reduce((sum, month) => sum + month.summary.countX, 0),
  };

  return {
    workerName: data.workerName || inferWorkerName(data.sourceFileName || "Ca_nhan.xlsx"),
    year,
    currency: data.currency || "TWD",
    sourceFileName: data.sourceFileName || "So_Cham_Cong.xlsx",
    generatedAt: data.generatedAt || new Date().toISOString(),
    totals,
    months,
    owners,
  };
}

export const bundledWorkbookData = normalizeWorkbookData(rawSeed);

function findWorkbookYear(workbook: XLSX.WorkBook) {
  for (const sheetName of workbook.SheetNames) {
    if (!sheetName.startsWith("Th")) continue;
    const sheet = workbook.Sheets[sheetName];
    for (let row = 2; row <= 40; row += 1) {
      const value = sheet[`A${row}`]?.v;
      if (value instanceof Date) return value.getUTCFullYear();
      if (typeof value === "number") {
        const parsed = XLSX.SSF.parse_date_code(value);
        if (parsed) return parsed.y;
      }
      if (typeof value === "string" && value.trim()) {
        const parsed = new Date(value);
        if (!Number.isNaN(parsed.getTime())) return parsed.getUTCFullYear();
      }
    }
  }

  return bundledWorkbookData.year;
}

function readNumericCell(sheet: XLSX.WorkSheet | undefined, ref: string, fallback: number) {
  return Number(sheet?.[ref]?.v ?? fallback);
}

export function parseWorkbookArrayBuffer(arrayBuffer: ArrayBuffer, sourceFileName: string) {
  const workbook = XLSX.read(arrayBuffer, {
    type: "array",
    cellDates: true,
  });

  const year = findWorkbookYear(workbook);
  const monthSheets = workbook.SheetNames.filter((sheetName) => sheetName.startsWith("Th")).sort(
    (left, right) => parseMonthNumber(left) - parseMonthNumber(right)
  );

  const months = monthSheets.map((sheetName) => {
    const sheet = workbook.Sheets[sheetName];
    const monthNumber = parseMonthNumber(sheetName);
    const entries = createMonthEntries(sheet, year, monthNumber);
    const computedSummary = summarizeEntries(entries);

    return {
      id: `${year}-${String(monthNumber).padStart(2, "0")}`,
      label: formatMonthLabel(monthNumber),
      monthNumber,
      summary: {
        countO: readNumericCell(sheet, "C52", computedSummary.countO),
        countN: readNumericCell(sheet, "C53", computedSummary.countN),
        countX: readNumericCell(sheet, "C54", computedSummary.countX),
        gross: readNumericCell(sheet, "E52", computedSummary.gross),
        advance: readNumericCell(sheet, "F52", computedSummary.advance),
        net: readNumericCell(sheet, "G52", computedSummary.net),
        workUnits:
          readNumericCell(sheet, "C52", computedSummary.countO) +
          readNumericCell(sheet, "C53", computedSummary.countN) * 0.5,
      },
      entries,
    };
  });

  return normalizeWorkbookData({
    workerName: inferWorkerName(sourceFileName),
    year,
    currency: "TWD",
    sourceFileName,
    generatedAt: new Date().toISOString(),
    totals: {
      gross: 0,
      advance: 0,
      net: 0,
      workUnits: 0,
      countO: 0,
      countN: 0,
      countX: 0,
    },
    months,
    owners: [],
  });
}

export function getActiveMonths(data: PersonalWorkbookData) {
  return data.months.filter(
    (month) => month.summary.gross > 0 || month.entries.some((entry) => entry.hasActivity)
  );
}

export function getLatestActiveMonth(data: PersonalWorkbookData) {
  const activeMonths = getActiveMonths(data);
  return activeMonths[activeMonths.length - 1] || data.months[data.months.length - 1];
}

export function buildMonthOwnerSummary(month: MonthData) {
  return computeOwnerSummaries([{ ...month }]);
}

type WorkbookEntryPatch = {
  owner: string;
  mark: AttendanceMark;
  unitPrice: number;
  advance: number;
};

function applyEntryPatch(entry: WorkbookEntry, patch: WorkbookEntryPatch): WorkbookEntry {
  const owner = patch.owner.trim();
  const mark = normalizeMark(patch.mark);
  const amounts = calculateEntryAmounts(mark, patch.unitPrice, patch.advance);

  return {
    ...entry,
    owner,
    mark,
    unitPrice: amounts.unitPrice,
    advance: amounts.advance,
    wage: amounts.wage,
    net: amounts.net,
    hasActivity: Boolean(owner || mark || amounts.unitPrice || amounts.advance || amounts.wage || amounts.net),
  };
}

export function updateWorkbookEntry(
  data: PersonalWorkbookData,
  monthId: string,
  day: number,
  patch: WorkbookEntryPatch
) {
  return normalizeWorkbookData({
    ...data,
    generatedAt: new Date().toISOString(),
    months: data.months.map((month) =>
      month.id !== monthId
        ? month
        : {
            ...month,
            entries: month.entries.map((entry) =>
              entry.day !== day ? entry : applyEntryPatch(entry, patch)
            ),
          }
    ),
  });
}

export function clearWorkbookEntry(data: PersonalWorkbookData, monthId: string, day: number) {
  return updateWorkbookEntry(data, monthId, day, {
    owner: "",
    mark: "",
    unitPrice: 0,
    advance: 0,
  });
}

export function updateWorkbookProfile(
  data: PersonalWorkbookData,
  patch: {
    workerName: string;
    sourceFileName: string;
    year: number;
  }
) {
  const normalizedYear = Number.isFinite(Number(patch.year)) ? Number(patch.year) : data.year;

  return normalizeWorkbookData({
    ...data,
    workerName: patch.workerName.trim() || data.workerName,
    sourceFileName: patch.sourceFileName.trim() || data.sourceFileName,
    year: normalizedYear,
    generatedAt: new Date().toISOString(),
  });
}
